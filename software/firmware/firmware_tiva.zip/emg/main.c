#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "utils/uartstdio.h"
#include "driverlib/interrupt.h"
#include "inc/hw_ints.h"
#include "driverlib/timer.h"
#include "inc/hw_timer.h"
#include "driverlib/adc.h"

#define NUM_CHANNELS 4
#define MAX_LENGTH_PACKET NUM_CHANNELS*4 + 4
#define MAX_LENGTH_CMD 10

uint32_t adc_values[NUM_CHANNELS];
char packet[MAX_LENGTH_PACKET];

void uintTostr(uint32_t* num, char* str)
{
    char const digit[] = "0123456789";
    char *p = str;
    int i, j;

    for(i = 0; i < NUM_CHANNELS; i++)
    {
        int shifter = num[i];

        do
        {
            p++;
            shifter = shifter/10;
        }
        while(shifter);

        *p = ' ';

        do
        {
            *--p = digit[num[i]%10];
            num[i] = num[i]/10;
            shifter++;
        }
        while(num[i]);

        if(i == NUM_CHANNELS) shifter--;
        for(j = 0; j <= shifter; j++) p++;
    }
    *p = '\n';
}

int lengthStr(char* str)
{
    int i = 0;
    while(str[i] != '\n') i++;
    return i + 1;
}

unsigned char compareStr(char* str1, char* str2)
{
    int i = 0;

    if(lengthStr(str1) == lengthStr(str2))
        while(str1[i] != '\n')
        {
            if(str1[i] != str2[i]) return 0;
            else i++;
        }
    else return 0;
    return 1;
}

void uartSend(char *str, int length)
{
    int i = 0;
    while(length--) UARTCharPut(UART0_BASE, str[i++]);
}

void timer0AInterrupt(void)
{
    ADCSequenceDataGet(ADC0_BASE, 1, adc_values);
    uintTostr(adc_values, packet);
    uartSend(packet, lengthStr(packet));

    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
}

void uart0Interrupt(void)
{
    char cmd[MAX_LENGTH_PACKET];
    int i = 0;
    
    while(UARTCharsAvail(UART0_BASE)) cmd[i++] = (char)UARTCharGetNonBlocking(UART0_BASE);
    
    if(compareStr(cmd, "start\n")) IntEnable(INT_TIMER0A);
    else if(compareStr(cmd, "stop\n")) IntDisable(INT_TIMER0A);

    UARTIntClear(UART0_BASE, UART_INT_RX | UART_INT_RT);
}

void configureUART(int baudrate)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTConfigSetExpClk(UART0_BASE, SysCtlClockGet(), baudrate, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));
    UARTIntEnable(UART0_BASE, UART_INT_RX | UART_INT_RT);
    IntPrioritySet(INT_UART0, 0);
    IntEnable(INT_UART0);
}

void configureTimer(int samplerate)
{
    uint32_t period;

    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);

    period = (SysCtlClockGet()/samplerate);

    TimerLoadSet(TIMER0_BASE, TIMER_A, period - 1);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER0_BASE, TIMER_A);

    TimerControlTrigger(TIMER0_BASE, TIMER_A, true);
}

void configureADC(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);

    GPIOPinTypeADC(GPIO_PORTD_BASE, GPIO_PIN_2|GPIO_PIN_3);
    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_1|GPIO_PIN_2);

    ADCReferenceSet(ADC0_BASE, ADC_REF_INT);

    ADCSequenceConfigure(ADC0_BASE, 1, ADC_TRIGGER_TIMER, 0);
    ADCSequenceStepConfigure(ADC0_BASE, 1, 0, ADC_CTL_CH0);
    ADCSequenceStepConfigure(ADC0_BASE, 1, 1, ADC_CTL_CH1);
    ADCSequenceStepConfigure(ADC0_BASE, 1, 2, ADC_CTL_CH2);
    ADCSequenceStepConfigure(ADC0_BASE, 1, 3, ADC_CTL_CH3|ADC_CTL_IE|ADC_CTL_END);
    ADCSequenceEnable(ADC0_BASE, 1);
}

void configurations()
{
    int samplerate = 2000, baudrate = 115200;

    SysCtlClockSet(SYSCTL_SYSDIV_5|SYSCTL_USE_PLL|SYSCTL_XTAL_16MHZ|SYSCTL_OSC_MAIN);
    IntMasterEnable();

    configureADC();
    configureTimer(samplerate);
    configureUART(baudrate);
}

void main(void)
{
    configurations();
    while(1);
}
