#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "utils/uartstdio.h"
#include "driverlib/interrupt.h"
#include "inc/hw_ints.h"
#include "driverlib/timer.h"
#include "inc/hw_timer.h"
#include "driverlib/adc.h"

#define NUM_CHANNELS 4
#define MAX_LENGTH_PACKET NUM_CHANNELS*2 + 4
#define SHIFT 128

static uint32_t ui32ADC0Value[NUM_CHANNELS];
static char packet[MAX_LENGTH_PACKET];

int uint12ToStr(uint32_t* n)
{
    unsigned int i, j;

    j = 0;

    for (i = 0; i < NUM_CHANNELS; i++)
    {
        if (n[i] >= 1<<12)
        {
			printf("%s: %s: Error: n outside interval [0, %d]\n",
				   __FILE__, __FUNCTION__, 1<<12);
			return 0;
        }
        packet[i + j] = (n[i]>>6) + SHIFT;
        packet[i + j + 1] = n[i] % (1<<6) + SHIFT;
        packet[i + j + 2] = ' ';

        j = j + 2;
    }

    packet[MAX_LENGTH_PACKET - 1] = '\n';

    return 1;
}

void ConfigureUART(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);
    UARTStdioConfig(0, 115200, 16000000);
}

void ConfigureTimer(void)
{
    unsigned long period;
    float samplerate = 2000;

    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);

    period = (SysCtlClockGet()/samplerate);

    TimerLoadSet(TIMER0_BASE, TIMER_A, period - 1);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER0_BASE, TIMER_A);
    IntEnable(INT_TIMER0A);

    TimerControlTrigger(TIMER0_BASE, TIMER_A, true);
}

void ConfigureGPIO(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);

    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4);
}

void ConfigureADC(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);

    ADCSequenceConfigure(ADC0_BASE, 1, ADC_TRIGGER_TIMER, 0);

    ADCSequenceStepConfigure(ADC0_BASE, 1, 0, ADC_CTL_CH0);
    ADCSequenceStepConfigure(ADC0_BASE, 1, 1, ADC_CTL_CH1);
    ADCSequenceStepConfigure(ADC0_BASE, 1, 2, ADC_CTL_CH2);
    ADCSequenceStepConfigure(ADC0_BASE, 1, 3, ADC_CTL_CH3|ADC_CTL_IE|ADC_CTL_END);

    ADCSequenceEnable(ADC0_BASE, 1);
}

void Timer0IntHandler(void)
{
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);

    ADCSequenceDataGet(ADC0_BASE, 1, ui32ADC0Value);

    ui32ADC0Value[0] = 0;
    ui32ADC0Value[1] = 1000;
    ui32ADC0Value[2] = 2000;

    if (uint12ToStr(ui32ADC0Value))
    	UARTprintf(packet);
}

int main(void)
{
    SysCtlClockSet(SYSCTL_SYSDIV_5|SYSCTL_USE_PLL|SYSCTL_XTAL_16MHZ|SYSCTL_OSC_MAIN);

    ConfigureGPIO();
    ConfigureADC();
    ConfigureTimer();
    ConfigureUART();

    while(1) {}
}
