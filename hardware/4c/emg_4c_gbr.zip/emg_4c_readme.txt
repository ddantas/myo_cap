LABCENTER PROTEUS TOOL INFORMATION FILE
=======================================

In case of difficulty, please e-mail support@labcenter.co.uk

Tool set up for Proteus layout 'emg_4c_proteus.pdsprj'.
CADCAM generated at 16:34:01 on sexta-feira, 28 de julho de 2017.

File List
---------
Top Copper              : emg_4c_proteus - CADCAM Top Copper.GBR
Bottom Copper           : emg_4c_proteus - CADCAM Bottom Copper.GBR
Top Silk Screen         : emg_4c_proteus - CADCAM Top Silk Screen.GBR
Top Solder Resist       : emg_4c_proteus - CADCAM Top Solder Resist.GBR
Bottom Solder Resist    : emg_4c_proteus - CADCAM Bottom Solder Resist.GBR
Mechanical 1            : emg_4c_proteus - CADCAM Mechanical 1.GBR
Top Assembly            : emg_4c_proteus - CADCAM Top Assembly.GBR
Drill                   : emg_4c_proteus - CADCAM Drill.DRL
Netlist                 : emg_4c_proteus - CADCAM Netlist.IPC

Photoplotter Setup
------------------
Format: RS274X, ASCII, 4.3, metric, absolute, eob=*, LZO
Notes:  D=Diameter, S=Side, W=Width, H=Height, C=Chamfer, I=Index

D10	CIRCLE  D=1.27mm                                                          DRAW 
D11	CIRCLE  D=1.27mm                                                          FLASH
D12	CIRCLE  D=2.032mm                                                         FLASH
D13	SQUARE  S=1.27mm                                                          FLASH
D14	SQUARE  S=1.778mm                                                         FLASH
D15	CIRCLE  D=6.35mm                                                          FLASH
D16	CIRCLE  D=1.778mm                                                         FLASH
D17	CIRCLE  D=2.54mm                                                          FLASH
D18	CIRCLE  D=3.048mm                                                         FLASH
D19	DIL     W=1.524mm             H=2.54mm              C=0.3048mm            FLASH
D70	CIRCLE  D=0.2032mm                                                        DRAW 
D71	CIRCLE  D=0.03175mm                                                       DRAW 
D20	CIRCLE  D=1.524mm                                                         FLASH
D21	CIRCLE  D=2.286mm                                                         FLASH
D22	PPAD    W=1.524mm             H=1.524mm             I=0                   FLASH
D23	PPAD    W=1.524mm             H=1.524mm             I=1                   FLASH
D24	PPAD    W=2.032mm             H=2.032mm             I=2                   FLASH
D25	CIRCLE  D=6.604mm                                                         FLASH
D26	CIRCLE  D=2.794mm                                                         FLASH
D27	CIRCLE  D=3.302mm                                                         FLASH
D28	PPAD    W=1.778mm             H=2.794mm             I=3                   FLASH
D29	CIRCLE  D=0.5334mm                                                        DRAW 
D72	CIRCLE  D=0.32207mm                                                       DRAW 
D73	CIRCLE  D=0.10668mm                                                       DRAW 
D30	CIRCLE  D=0.0508mm                                                        DRAW 
D31	CIRCLE  D=0.361mm                                                         DRAW 
D32	CIRCLE  D=0.25738mm                                                       DRAW 
D33	CIRCLE  D=0.1103mm                                                        DRAW 
D34	CIRCLE  D=0.11176mm                                                       DRAW 

NC Drill Setup
--------------
Format: Excellon, ASCII, 4.3, metric, absolute, eob=<CR><LF>, no zero suppression.
Notes:  Tool sizes are diameters. Layer sets are in brackets - 0=TOP, 15=BOTTOM, 1-14=INNER.

T01	0.381mm (0-15) Plated
T02	0.508mm (0-15) Plated
T03	0.762mm (0-15) Plated
T04	3mm (0-15) Plated
T05	1.143mm (0-15) Plated
T06	1.524mm (0-15) Plated
T07	1mm (0-15) Plated
T08	1.016mm (0-15) Plated


[END OF FILE]
